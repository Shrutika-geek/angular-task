import { state } from '@angular/animations';
import { createFeatureSelector, createSelector } from '@ngrx/store';
import { Book } from 'src/app/model/book.model';
import { BookState } from '../reducer/book.reducer';

const selectBookState = createFeatureSelector<BookState>('book');

export const selectBooks = createSelector(
  selectBookState,
  (state: BookState) => state.books
);
