import { Book } from 'src/app/model/book.model';
import { createAction, props } from '@ngrx/store';

export const FETCH_BOOKS = '[BOOK compoenent] FETCH_BOOKS';
export const UPDATE_BOOKS = '[BOOK component] UPDATE_BOOK';
export const ADD_BOOKS = '[BOOK component] ADD_BOOK';
export const DELETE_BOOK = '[BOOK component] DELETE_BOOK';

export const fetchBook = createAction(FETCH_BOOKS, props<{ books: Book[] }>());

export const addBook = createAction(ADD_BOOKS, props<{ book: Book }>());

export const updateBook = createAction(
  UPDATE_BOOKS,
  props<{ id: string; book: Book }>()
);

export const deleteBook = createAction(DELETE_BOOK, props<{ id: string }>());
