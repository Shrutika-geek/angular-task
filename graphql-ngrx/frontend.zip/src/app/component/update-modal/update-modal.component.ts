import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-update-modal',
  templateUrl: './update-modal.component.html',
  styleUrls: ['./update-modal.component.css'],
})
export class UpdateModalComponent implements OnInit {
  @Input() book!: any;
  @Output() onUpdate: EventEmitter<any> = new EventEmitter();
  bookName: String = '';
  authorName: String = '';

  ngOnInit() {
    this.bookName = this.book.book;
    this.authorName = this.book.author;
  }

  update() {
    console.log('Book id', this.book._id);
    this.onUpdate.emit({
      _id: this.book._id,
      book: this.bookName,
      author: this.authorName,
    });
  }
}
