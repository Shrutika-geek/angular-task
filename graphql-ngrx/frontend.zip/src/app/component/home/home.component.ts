import { Component, OnInit } from '@angular/core';
import { Apollo } from 'apollo-angular';
import gql from 'graphql-tag';
import { AddModalComponent } from '../add-modal/add-modal.component';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
const GET_BOOKS = gql`
  {
    books {
      books {
        _id
        book
        author
      }
    }
  }
`;

const CREATE_BOOK = gql`
  mutation createBook($book: String!, $author: String!) {
    createBook(bookInput: { book: $book, author: $author }) {
      _id
      book
      author
    }
  }
`;

const DELETE_BOOK = gql`
  mutation deleteBook($id: ID!) {
    deleteBook(id: $id) {
      _id
      book
      author
    }
  }
`;

const UPDATE_BOOK = gql`
  mutation updateBook($id: ID!, $book: String!, $author: String!) {
    updateBook(id: $id, bookInput: { book: $book, author: $author }) {
      _id
      book
      author
    }
  }
`;
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent {
  books!: any;

  constructor(private apollo: Apollo) {}

  ngOnInit() {
    this.apollo
      .watchQuery({
        query: GET_BOOKS,
      })
      .valueChanges.pipe(
        map((result: any) => {
          console.log(result.data.books.books);
          return result.data.books.books;
        })
      )
      .subscribe((data) => {
        this.books = data;
      });
  }

  create(payload: { book: string; author: string }) {
    const { book, author } = payload;
    this.apollo
      .mutate({
        mutation: CREATE_BOOK,
        refetchQueries: [{ query: GET_BOOKS }],
        variables: {
          book: book,
          author: author,
        },
      })
      .subscribe(() => {
        console.log('created');
      });
  }

  delete(id: string) {
    console.log(id);
    this.apollo
      .mutate({
        mutation: DELETE_BOOK,
        refetchQueries: [{ query: GET_BOOKS }],
        variables: {
          id: id,
        },
      })
      .subscribe(() => {
        console.log('deleted');
      });
  }

  update(event: { _id: string; book: string; author: string }) {
    const { _id, book, author } = event;
    console.log(_id, book, author);
    this.apollo
      .mutate({
        mutation: UPDATE_BOOK,
        refetchQueries: [{ query: GET_BOOKS }],
        variables: {
          id: _id,
          book: book,
          author: author,
        },
      })
      .subscribe(() => {
        console.log('updated');
      });
  }
}
