export interface Book {
  id: string;
  book: string;
  author: string;
}
